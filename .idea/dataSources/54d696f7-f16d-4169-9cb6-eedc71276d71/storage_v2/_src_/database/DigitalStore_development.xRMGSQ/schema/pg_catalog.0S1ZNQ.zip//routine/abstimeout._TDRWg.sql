create function abstimeout(abstime) returns cstring
  language internal
as
$$
abstimeout
$$;

comment on function abstimeout(abstime) is 'I/O';

