create function anyenum_in(cstring) returns anyenum
  language internal
as
$$
anyenum_in
$$;

comment on function anyenum_in(cstring) is 'I/O';

