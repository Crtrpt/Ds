create function btfloat4cmp(real, real) returns integer
  language internal
as
$$
btfloat4cmp
$$;

comment on function btfloat4cmp(float4, float4) is 'less-equal-greater';

