create function boolge(boolean, boolean) returns boolean
  language internal
as
$$
boolge
$$;

comment on function boolge(bool, bool) is 'implementation of >= operator';

