create function array_replace(anyarray, anyelement, anyelement) returns anyarray
  language internal
as
$$
array_replace
$$;

comment on function array_replace(anyarray, anyelement, anyelement) is 'replace any occurrences of an element in an array';

