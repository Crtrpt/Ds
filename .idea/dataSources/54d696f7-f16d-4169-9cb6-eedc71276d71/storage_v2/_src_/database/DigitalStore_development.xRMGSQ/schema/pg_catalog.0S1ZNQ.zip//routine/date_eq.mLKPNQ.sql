create function date_eq(date, date) returns boolean
  language internal
as
$$
date_eq
$$;

comment on function date_eq(date, date) is 'implementation of = operator';

