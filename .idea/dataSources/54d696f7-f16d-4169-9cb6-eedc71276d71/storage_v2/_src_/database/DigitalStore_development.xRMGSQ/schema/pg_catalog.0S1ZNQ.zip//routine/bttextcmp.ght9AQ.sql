create function bttextcmp(text, text) returns integer
  language internal
as
$$
bttextcmp
$$;

comment on function bttextcmp(text, text) is 'less-equal-greater';

