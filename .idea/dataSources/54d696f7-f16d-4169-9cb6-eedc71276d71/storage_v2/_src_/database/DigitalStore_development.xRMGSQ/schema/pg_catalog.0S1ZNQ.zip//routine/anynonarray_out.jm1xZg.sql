create function anynonarray_out(anynonarray) returns cstring
  language internal
as
$$
anynonarray_out
$$;

comment on function anynonarray_out(anynonarray) is 'I/O';

