create function current_query() returns text
  language internal
as
$$
current_query
$$;

comment on function current_query() is 'get the currently executing query';

