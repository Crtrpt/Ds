create function circle_below(circle, circle) returns boolean
  language internal
as
$$
circle_below
$$;

comment on function circle_below(circle, circle) is 'implementation of <<| operator';

