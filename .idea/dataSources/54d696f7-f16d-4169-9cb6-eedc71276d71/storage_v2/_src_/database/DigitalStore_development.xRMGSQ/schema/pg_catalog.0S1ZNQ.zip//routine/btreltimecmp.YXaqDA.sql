create function btreltimecmp(reltime, reltime) returns integer
  language internal
as
$$
btreltimecmp
$$;

comment on function btreltimecmp(reltime, reltime) is 'less-equal-greater';

