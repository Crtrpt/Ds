create function box(point, point) returns box
  language internal
as
$$
points_box
$$;

comment on function box(point, point) is 'convert points to box';

