create function abstimege(abstime, abstime) returns boolean
  language internal
as
$$
abstimege
$$;

comment on function abstimege(abstime, abstime) is 'implementation of >= operator';

