create function array_ge(anyarray, anyarray) returns boolean
  language internal
as
$$
array_ge
$$;

comment on function array_ge(anyarray, anyarray) is 'implementation of >= operator';

