create function bitge(bit, bit) returns boolean
  language internal
as
$$
bitge
$$;

comment on function bitge(bit, bit) is 'implementation of >= operator';

