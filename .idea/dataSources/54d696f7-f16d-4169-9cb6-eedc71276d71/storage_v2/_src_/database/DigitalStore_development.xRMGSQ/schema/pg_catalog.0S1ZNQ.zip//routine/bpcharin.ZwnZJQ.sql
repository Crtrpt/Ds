create function bpcharin(cstring, oid, integer) returns character
  language internal
as
$$
bpcharin
$$;

comment on function bpcharin(cstring, oid, int4) is 'I/O';

