create function cash_mul_int8(money, bigint) returns money
  language internal
as
$$
cash_mul_int8
$$;

comment on function cash_mul_int8(money, int8) is 'implementation of * operator';

