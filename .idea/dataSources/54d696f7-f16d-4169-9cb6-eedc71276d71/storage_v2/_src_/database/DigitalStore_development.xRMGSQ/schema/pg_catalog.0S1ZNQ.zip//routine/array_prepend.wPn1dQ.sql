create function array_prepend(anyelement, anyarray) returns anyarray
  language internal
as
$$
array_prepend
$$;

comment on function array_prepend(anyelement, anyarray) is 'prepend element onto front of array';

