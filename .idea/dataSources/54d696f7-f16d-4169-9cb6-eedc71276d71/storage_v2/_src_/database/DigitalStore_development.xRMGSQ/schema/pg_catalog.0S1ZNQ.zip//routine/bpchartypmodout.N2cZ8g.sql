create function bpchartypmodout(integer) returns cstring
  language internal
as
$$
bpchartypmodout
$$;

comment on function bpchartypmodout(int4) is 'I/O typmod';

