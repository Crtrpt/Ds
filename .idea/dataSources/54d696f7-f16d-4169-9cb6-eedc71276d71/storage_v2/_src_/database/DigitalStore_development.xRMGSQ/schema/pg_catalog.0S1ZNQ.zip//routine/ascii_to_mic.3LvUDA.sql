create function ascii_to_mic(integer, integer, cstring, internal, integer) returns void
  language c
as
$$
ascii_to_mic
$$;

comment on function ascii_to_mic(int4, int4, cstring, internal, int4) is 'internal conversion function for SQL_ASCII to MULE_INTERNAL';

