create function area(box) returns double precision
  language internal
as
$$
box_area
$$;

comment on function area(box) is 'box area';

