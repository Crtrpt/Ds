create function abstimerecv(internal) returns abstime
  language internal
as
$$
abstimerecv
$$;

comment on function abstimerecv(internal) is 'I/O';

