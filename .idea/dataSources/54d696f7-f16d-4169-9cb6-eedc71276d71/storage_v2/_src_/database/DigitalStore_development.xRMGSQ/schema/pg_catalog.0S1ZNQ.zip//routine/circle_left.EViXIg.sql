create function circle_left(circle, circle) returns boolean
  language internal
as
$$
circle_left
$$;

comment on function circle_left(circle, circle) is 'implementation of << operator';

