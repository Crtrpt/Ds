create function box(point, point) returns box
  language internal
as
$$
points_box
$$;

comment on function box(circle) is 'convert circle to box';

