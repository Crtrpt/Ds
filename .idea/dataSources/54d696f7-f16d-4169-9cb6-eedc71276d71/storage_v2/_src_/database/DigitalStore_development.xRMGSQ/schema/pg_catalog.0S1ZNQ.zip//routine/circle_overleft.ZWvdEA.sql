create function circle_overleft(circle, circle) returns boolean
  language internal
as
$$
circle_overleft
$$;

comment on function circle_overleft(circle, circle) is 'implementation of &< operator';

