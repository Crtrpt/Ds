create function abstime(timestamp without time zone) returns abstime
  language internal
as
$$
timestamp_abstime
$$;

comment on function abstime(timestamp) is 'convert timestamp to abstime';

