create function ascii_to_utf8(integer, integer, cstring, internal, integer) returns void
  language c
as
$$
ascii_to_utf8
$$;

comment on function ascii_to_utf8(int4, int4, cstring, internal, int4) is 'internal conversion function for SQL_ASCII to UTF8';

