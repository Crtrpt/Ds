create function boolle(boolean, boolean) returns boolean
as
$$
boolle
$$;

comment on function boolle(bool, bool) is 'implementation of <= operator';

