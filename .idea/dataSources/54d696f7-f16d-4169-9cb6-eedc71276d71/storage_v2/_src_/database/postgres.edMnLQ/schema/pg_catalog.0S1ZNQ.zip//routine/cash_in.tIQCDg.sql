create function cash_in(cstring) returns money
as
$$
cash_in
$$;

comment on function cash_in(cstring) is 'I/O';

