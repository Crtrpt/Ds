create function abbrev(cidr) returns text
as
$$
cidr_abbrev
$$;

comment on function abbrev(inet) is 'abbreviated display of inet value';

