create function abstimesend(abstime) returns bytea
as
$$
abstimesend
$$;

comment on function abstimesend(abstime) is 'I/O';

