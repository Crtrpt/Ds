create function charout("char") returns cstring
as
$$
charout
$$;

comment on function charout("char") is 'I/O';

