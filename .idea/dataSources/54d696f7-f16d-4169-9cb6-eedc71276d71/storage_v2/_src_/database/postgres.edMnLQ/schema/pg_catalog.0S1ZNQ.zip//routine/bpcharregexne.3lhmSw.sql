create function bpcharregexne(character, text) returns boolean
as
$$
textregexne
$$;

comment on function bpcharregexne(bpchar, text) is 'implementation of !~ operator';

