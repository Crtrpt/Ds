create function bytea_sortsupport(internal) returns void
as
$$
bytea_sortsupport
$$;

comment on function bytea_sortsupport(internal) is 'sort support';

