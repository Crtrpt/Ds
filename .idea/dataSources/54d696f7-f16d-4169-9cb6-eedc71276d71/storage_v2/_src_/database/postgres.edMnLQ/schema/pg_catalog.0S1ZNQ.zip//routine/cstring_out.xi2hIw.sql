create function cstring_out(cstring) returns cstring
as
$$
cstring_out
$$;

comment on function cstring_out(cstring) is 'I/O';

