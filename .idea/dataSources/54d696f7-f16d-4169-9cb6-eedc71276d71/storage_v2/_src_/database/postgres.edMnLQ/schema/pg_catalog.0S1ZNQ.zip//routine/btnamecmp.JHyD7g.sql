create function btnamecmp(name, name) returns integer
as
$$
btnamecmp
$$;

comment on function btnamecmp(name, name) is 'less-equal-greater';

