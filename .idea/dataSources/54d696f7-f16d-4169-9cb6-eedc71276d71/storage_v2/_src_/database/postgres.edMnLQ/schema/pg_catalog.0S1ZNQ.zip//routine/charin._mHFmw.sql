create function charin(cstring) returns "char"
as
$$
charin
$$;

comment on function charin(cstring) is 'I/O';

