create function box_overleft(box, box) returns boolean
as
$$
box_overleft
$$;

comment on function box_overleft(box, box) is 'implementation of &< operator';

