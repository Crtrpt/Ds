create function abstimelt(abstime, abstime) returns boolean
as
$$
abstimelt
$$;

comment on function abstimelt(abstime, abstime) is 'implementation of < operator';

