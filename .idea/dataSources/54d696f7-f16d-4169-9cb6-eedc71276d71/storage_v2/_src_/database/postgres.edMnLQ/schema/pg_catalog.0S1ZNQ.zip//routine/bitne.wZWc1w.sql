create function bitne(bit, bit) returns boolean
as
$$
bitne
$$;

comment on function bitne(bit, bit) is 'implementation of <> operator';

