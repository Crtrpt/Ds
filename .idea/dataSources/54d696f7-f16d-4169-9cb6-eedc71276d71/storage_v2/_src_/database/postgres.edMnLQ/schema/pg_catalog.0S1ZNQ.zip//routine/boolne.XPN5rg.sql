create function boolne(boolean, boolean) returns boolean
as
$$
boolne
$$;

comment on function boolne(bool, bool) is 'implementation of <> operator';

