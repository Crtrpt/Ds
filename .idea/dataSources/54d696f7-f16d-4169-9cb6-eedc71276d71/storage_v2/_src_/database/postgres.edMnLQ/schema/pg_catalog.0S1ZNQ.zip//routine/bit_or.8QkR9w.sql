create function bit_or(smallint) returns smallint
as
$$
aggregate_dummy
$$;

comment on function bit_or(bit) is 'bitwise-or bit aggregate';

