create function array_out(anyarray) returns cstring
as
$$
array_out
$$;

comment on function array_out(anyarray) is 'I/O';

