create function boollt(boolean, boolean) returns boolean
as
$$
boollt
$$;

comment on function boollt(bool, bool) is 'implementation of < operator';

