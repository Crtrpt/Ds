create function array_ne(anyarray, anyarray) returns boolean
as
$$
array_ne
$$;

comment on function array_ne(anyarray, anyarray) is 'implementation of <> operator';

