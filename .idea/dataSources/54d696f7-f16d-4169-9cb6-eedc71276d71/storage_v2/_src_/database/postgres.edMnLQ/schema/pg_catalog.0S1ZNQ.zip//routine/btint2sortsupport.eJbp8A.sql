create function btint2sortsupport(internal) returns void
as
$$
btint2sortsupport
$$;

comment on function btint2sortsupport(internal) is 'sort support';

