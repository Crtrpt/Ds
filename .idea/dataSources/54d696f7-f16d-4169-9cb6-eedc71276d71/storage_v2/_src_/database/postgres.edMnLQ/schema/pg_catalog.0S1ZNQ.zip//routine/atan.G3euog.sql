create function atan(double precision) returns double precision
as
$$
datan
$$;

comment on function atan(float8) is 'arctangent';

