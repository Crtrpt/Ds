create function btarraycmp(anyarray, anyarray) returns integer
as
$$
btarraycmp
$$;

comment on function btarraycmp(anyarray, anyarray) is 'less-equal-greater';

