create function concat(VARIADIC "any") returns text
as
$$
text_concat
$$;

comment on function concat(any) is 'concatenate values';

