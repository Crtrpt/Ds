create function "RI_FKey_noaction_del"() returns trigger
as
$$
RI_FKey_noaction_del
$$;

comment on function "RI_FKey_noaction_del"() is 'referential integrity ON DELETE NO ACTION';

