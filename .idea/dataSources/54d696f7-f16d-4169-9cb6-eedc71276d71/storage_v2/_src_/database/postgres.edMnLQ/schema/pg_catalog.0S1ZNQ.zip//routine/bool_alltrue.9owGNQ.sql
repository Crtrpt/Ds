create function bool_alltrue(internal) returns boolean
as
$$
bool_alltrue
$$;

comment on function bool_alltrue(internal) is 'aggregate final function';

