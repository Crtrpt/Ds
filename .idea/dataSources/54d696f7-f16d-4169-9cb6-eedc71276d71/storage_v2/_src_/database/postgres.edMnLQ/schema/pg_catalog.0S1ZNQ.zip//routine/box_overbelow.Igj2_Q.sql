create function box_overbelow(box, box) returns boolean
as
$$
box_overbelow
$$;

comment on function box_overbelow(box, box) is 'implementation of &<| operator';

