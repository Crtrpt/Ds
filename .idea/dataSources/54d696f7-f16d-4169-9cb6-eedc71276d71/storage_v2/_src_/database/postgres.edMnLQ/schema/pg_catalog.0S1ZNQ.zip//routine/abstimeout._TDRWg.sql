create function abstimeout(abstime) returns cstring
as
$$
abstimeout
$$;

comment on function abstimeout(abstime) is 'I/O';

