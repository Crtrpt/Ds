create function acos(double precision) returns double precision
as
$$
dacos
$$;

comment on function acos(float8) is 'arccosine';

