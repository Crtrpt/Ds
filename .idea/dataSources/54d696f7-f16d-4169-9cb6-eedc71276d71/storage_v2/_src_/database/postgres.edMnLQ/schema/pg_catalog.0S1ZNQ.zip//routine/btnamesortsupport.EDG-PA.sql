create function btnamesortsupport(internal) returns void
as
$$
btnamesortsupport
$$;

comment on function btnamesortsupport(internal) is 'sort support';

