create function circle_lt(circle, circle) returns boolean
as
$$
circle_lt
$$;

comment on function circle_lt(circle, circle) is 'implementation of < operator';

