create function acosd(double precision) returns double precision
as
$$
dacosd
$$;

comment on function acosd(float8) is 'arccosine, degrees';

