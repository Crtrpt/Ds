create function boolsend(boolean) returns bytea
as
$$
boolsend
$$;

comment on function boolsend(bool) is 'I/O';

