create function abstimeeq(abstime, abstime) returns boolean
as
$$
abstimeeq
$$;

comment on function abstimeeq(abstime, abstime) is 'implementation of = operator';

