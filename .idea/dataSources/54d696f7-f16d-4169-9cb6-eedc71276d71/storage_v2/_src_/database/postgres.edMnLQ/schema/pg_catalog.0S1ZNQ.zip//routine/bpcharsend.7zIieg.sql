create function bpcharsend(character) returns bytea
as
$$
bpcharsend
$$;

comment on function bpcharsend(bpchar) is 'I/O';

