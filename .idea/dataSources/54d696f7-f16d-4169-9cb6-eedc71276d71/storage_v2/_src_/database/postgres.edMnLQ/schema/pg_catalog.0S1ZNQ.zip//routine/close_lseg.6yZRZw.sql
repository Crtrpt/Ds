create function close_lseg(lseg, lseg) returns point
as
$$
close_lseg
$$;

comment on function close_lseg(lseg, lseg) is 'implementation of ## operator';

