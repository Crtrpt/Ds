create function btint8cmp(bigint, bigint) returns integer
as
$$
btint8cmp
$$;

comment on function btint8cmp(int8, int8) is 'less-equal-greater';

