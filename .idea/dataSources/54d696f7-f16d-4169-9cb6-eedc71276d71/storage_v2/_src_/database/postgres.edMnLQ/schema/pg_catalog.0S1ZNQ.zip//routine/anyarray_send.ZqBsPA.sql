create function anyarray_send(anyarray) returns bytea
as
$$
anyarray_send
$$;

comment on function anyarray_send(anyarray) is 'I/O';

