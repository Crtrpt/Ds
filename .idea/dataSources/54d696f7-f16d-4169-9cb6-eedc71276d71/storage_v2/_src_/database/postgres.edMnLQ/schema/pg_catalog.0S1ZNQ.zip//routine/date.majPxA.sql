create function date(timestamp with time zone) returns date
as
$$
timestamptz_date
$$;

comment on function date(timestamptz) is 'convert timestamp with time zone to date';

