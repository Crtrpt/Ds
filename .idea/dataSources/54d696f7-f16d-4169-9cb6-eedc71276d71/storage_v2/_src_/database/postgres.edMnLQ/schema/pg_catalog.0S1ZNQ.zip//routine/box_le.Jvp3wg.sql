create function box_le(box, box) returns boolean
as
$$
box_le
$$;

comment on function box_le(box, box) is 'implementation of <= operator';

