create function bit_out(bit) returns cstring
as
$$
bit_out
$$;

comment on function bit_out(bit) is 'I/O';

