create function bpcharcmp(character, character) returns integer
as
$$
bpcharcmp
$$;

comment on function bpcharcmp(bpchar, bpchar) is 'less-equal-greater';

