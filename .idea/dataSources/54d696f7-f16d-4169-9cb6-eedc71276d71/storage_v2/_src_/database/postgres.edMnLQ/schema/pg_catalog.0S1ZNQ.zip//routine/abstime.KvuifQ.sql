create function abstime(timestamp without time zone) returns abstime
as
$$
timestamp_abstime
$$;

comment on function abstime(timestamptz) is 'convert timestamp with time zone to abstime';

