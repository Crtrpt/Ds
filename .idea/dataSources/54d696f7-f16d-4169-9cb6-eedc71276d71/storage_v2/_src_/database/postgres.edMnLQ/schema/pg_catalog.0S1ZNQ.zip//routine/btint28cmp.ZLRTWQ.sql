create function btint28cmp(smallint, bigint) returns integer
as
$$
btint28cmp
$$;

comment on function btint28cmp(int2, int8) is 'less-equal-greater';

