create function btoidsortsupport(internal) returns void
as
$$
btoidsortsupport
$$;

comment on function btoidsortsupport(internal) is 'sort support';

