create function charsend("char") returns bytea
as
$$
charsend
$$;

comment on function charsend("char") is 'I/O';

