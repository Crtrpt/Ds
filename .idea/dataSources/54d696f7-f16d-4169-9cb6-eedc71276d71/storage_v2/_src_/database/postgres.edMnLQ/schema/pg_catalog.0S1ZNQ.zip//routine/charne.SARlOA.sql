create function charne("char", "char") returns boolean
as
$$
charne
$$;

comment on function charne("char", "char") is 'implementation of <> operator';

