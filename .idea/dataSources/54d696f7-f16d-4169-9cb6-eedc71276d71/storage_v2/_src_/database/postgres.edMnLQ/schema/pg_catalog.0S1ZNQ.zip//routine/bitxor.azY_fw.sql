create function bitxor(bit, bit) returns bit
as
$$
bitxor
$$;

comment on function bitxor(bit, bit) is 'implementation of # operator';

