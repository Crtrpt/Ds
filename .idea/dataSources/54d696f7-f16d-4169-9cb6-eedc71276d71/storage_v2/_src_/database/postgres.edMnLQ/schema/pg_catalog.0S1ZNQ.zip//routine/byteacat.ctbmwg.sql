create function byteacat(bytea, bytea) returns bytea
as
$$
byteacat
$$;

comment on function byteacat(bytea, bytea) is 'implementation of || operator';

