create function bpcharrecv(internal, oid, integer) returns character
as
$$
bpcharrecv
$$;

comment on function bpcharrecv(internal, oid, int4) is 'I/O';

