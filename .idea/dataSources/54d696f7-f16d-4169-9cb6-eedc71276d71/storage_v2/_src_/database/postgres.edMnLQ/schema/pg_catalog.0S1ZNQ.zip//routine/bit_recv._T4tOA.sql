create function bit_recv(internal, oid, integer) returns bit
as
$$
bit_recv
$$;

comment on function bit_recv(internal, oid, int4) is 'I/O';

