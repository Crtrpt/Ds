create function "RI_FKey_noaction_upd"() returns trigger
as
$$
RI_FKey_noaction_upd
$$;

comment on function "RI_FKey_noaction_upd"() is 'referential integrity ON UPDATE NO ACTION';

