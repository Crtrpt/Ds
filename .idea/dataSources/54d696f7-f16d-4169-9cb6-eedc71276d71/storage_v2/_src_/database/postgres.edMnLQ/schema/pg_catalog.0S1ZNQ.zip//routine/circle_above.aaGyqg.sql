create function circle_above(circle, circle) returns boolean
as
$$
circle_above
$$;

comment on function circle_above(circle, circle) is 'implementation of |>> operator';

