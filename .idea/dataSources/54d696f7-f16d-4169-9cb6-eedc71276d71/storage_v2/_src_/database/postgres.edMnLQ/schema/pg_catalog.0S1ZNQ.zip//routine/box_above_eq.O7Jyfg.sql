create function box_above_eq(box, box) returns boolean
as
$$
box_above_eq
$$;

comment on function box_above_eq(box, box) is 'implementation of >^ operator';

