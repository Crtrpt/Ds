create function boolge(boolean, boolean) returns boolean
as
$$
boolge
$$;

comment on function boolge(bool, bool) is 'implementation of >= operator';

