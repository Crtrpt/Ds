create function abs(real) returns real
as
$$
float4abs
$$;

comment on function abs(numeric) is 'absolute value';

