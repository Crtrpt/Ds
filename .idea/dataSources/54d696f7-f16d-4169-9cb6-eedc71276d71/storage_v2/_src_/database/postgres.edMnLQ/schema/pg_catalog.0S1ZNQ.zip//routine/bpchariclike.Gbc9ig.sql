create function bpchariclike(character, text) returns boolean
as
$$
texticlike
$$;

comment on function bpchariclike(bpchar, text) is 'implementation of ~~* operator';

