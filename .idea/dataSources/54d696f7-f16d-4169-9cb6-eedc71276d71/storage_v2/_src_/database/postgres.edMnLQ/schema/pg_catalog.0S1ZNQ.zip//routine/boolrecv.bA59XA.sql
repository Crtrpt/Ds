create function boolrecv(internal) returns boolean
as
$$
boolrecv
$$;

comment on function boolrecv(internal) is 'I/O';

