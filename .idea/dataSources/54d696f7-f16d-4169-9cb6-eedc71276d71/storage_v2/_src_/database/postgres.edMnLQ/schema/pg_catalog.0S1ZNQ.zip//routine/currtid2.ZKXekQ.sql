create function currtid2(text, tid) returns tid
as
$$
currtid_byrelname
$$;

comment on function currtid2(text, tid) is 'latest tid of a tuple';

