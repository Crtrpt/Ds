create function bytealike(bytea, bytea) returns boolean
as
$$
bytealike
$$;

comment on function bytealike(bytea, bytea) is 'implementation of ~~ operator';

