create function cot(double precision) returns double precision
as
$$
dcot
$$;

comment on function cot(float8) is 'cotangent';

