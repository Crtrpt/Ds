create function abstimene(abstime, abstime) returns boolean
as
$$
abstimene
$$;

comment on function abstimene(abstime, abstime) is 'implementation of <> operator';

