create function boolout(boolean) returns cstring
as
$$
boolout
$$;

comment on function boolout(bool) is 'I/O';

