create function aclitemeq(aclitem, aclitem) returns boolean
as
$$
aclitem_eq
$$;

comment on function aclitemeq(aclitem, aclitem) is 'implementation of = operator';

