create function bitlt(bit, bit) returns boolean
as
$$
bitlt
$$;

comment on function bitlt(bit, bit) is 'implementation of < operator';

