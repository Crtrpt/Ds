create function currval(regclass) returns bigint
as
$$
currval_oid
$$;

comment on function currval(regclass) is 'sequence current value';

