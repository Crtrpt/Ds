create function cidsend(cid) returns bytea
as
$$
cidsend
$$;

comment on function cidsend(cid) is 'I/O';

