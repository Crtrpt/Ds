create function bytearecv(internal) returns bytea
as
$$
bytearecv
$$;

comment on function bytearecv(internal) is 'I/O';

