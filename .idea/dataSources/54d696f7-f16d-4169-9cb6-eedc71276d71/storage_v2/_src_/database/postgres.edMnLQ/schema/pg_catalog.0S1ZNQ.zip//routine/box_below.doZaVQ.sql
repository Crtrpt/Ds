create function box_below(box, box) returns boolean
as
$$
box_below
$$;

comment on function box_below(box, box) is 'implementation of <<| operator';

