create function btfloat84cmp(double precision, real) returns integer
as
$$
btfloat84cmp
$$;

comment on function btfloat84cmp(float8, float4) is 'less-equal-greater';

