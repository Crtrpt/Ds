create function box_add(box, point) returns box
as
$$
box_add
$$;

comment on function box_add(box, point) is 'implementation of + operator';

