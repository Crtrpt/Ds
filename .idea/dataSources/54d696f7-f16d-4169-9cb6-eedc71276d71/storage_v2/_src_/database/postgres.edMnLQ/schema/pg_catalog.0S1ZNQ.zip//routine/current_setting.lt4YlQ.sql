create function current_setting(text) returns text
as
$$
show_config_by_name
$$;

comment on function current_setting(text) is 'SHOW X as a function';

