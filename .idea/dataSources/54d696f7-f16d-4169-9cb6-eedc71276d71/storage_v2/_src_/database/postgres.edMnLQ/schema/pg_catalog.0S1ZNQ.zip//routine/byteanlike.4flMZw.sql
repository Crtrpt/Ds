create function byteanlike(bytea, bytea) returns boolean
as
$$
byteanlike
$$;

comment on function byteanlike(bytea, bytea) is 'implementation of !~~ operator';

