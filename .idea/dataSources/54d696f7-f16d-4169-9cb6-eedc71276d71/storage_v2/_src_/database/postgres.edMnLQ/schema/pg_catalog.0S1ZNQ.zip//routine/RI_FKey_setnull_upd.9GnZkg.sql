create function "RI_FKey_setnull_upd"() returns trigger
as
$$
RI_FKey_setnull_upd
$$;

comment on function "RI_FKey_setnull_upd"() is 'referential integrity ON UPDATE SET NULL';

