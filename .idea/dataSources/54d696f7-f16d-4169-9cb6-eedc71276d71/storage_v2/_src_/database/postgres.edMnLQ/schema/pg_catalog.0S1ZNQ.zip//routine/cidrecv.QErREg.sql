create function cidrecv(internal) returns cid
as
$$
cidrecv
$$;

comment on function cidrecv(internal) is 'I/O';

