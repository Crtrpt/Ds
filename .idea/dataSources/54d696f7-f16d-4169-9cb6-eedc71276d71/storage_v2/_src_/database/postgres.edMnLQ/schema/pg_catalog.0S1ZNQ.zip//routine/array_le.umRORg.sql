create function array_le(anyarray, anyarray) returns boolean
as
$$
array_le
$$;

comment on function array_le(anyarray, anyarray) is 'implementation of <= operator';

