create function char(integer) returns "char"
as
$$
i4tochar
$$;

comment on function char(text) is 'convert text to char';

