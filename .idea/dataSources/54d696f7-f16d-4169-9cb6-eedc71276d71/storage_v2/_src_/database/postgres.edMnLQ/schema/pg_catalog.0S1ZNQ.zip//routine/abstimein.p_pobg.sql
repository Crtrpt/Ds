create function abstimein(cstring) returns abstime
as
$$
abstimein
$$;

comment on function abstimein(cstring) is 'I/O';

