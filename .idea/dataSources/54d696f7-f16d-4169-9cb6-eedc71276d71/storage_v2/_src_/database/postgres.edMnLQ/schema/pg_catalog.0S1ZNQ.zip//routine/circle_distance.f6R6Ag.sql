create function circle_distance(circle, circle) returns double precision
as
$$
circle_distance
$$;

comment on function circle_distance(circle, circle) is 'implementation of <-> operator';

