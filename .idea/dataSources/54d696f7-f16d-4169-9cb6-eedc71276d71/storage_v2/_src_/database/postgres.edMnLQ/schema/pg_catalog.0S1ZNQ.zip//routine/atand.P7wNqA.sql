create function atand(double precision) returns double precision
as
$$
datand
$$;

comment on function atand(float8) is 'arctangent, degrees';

