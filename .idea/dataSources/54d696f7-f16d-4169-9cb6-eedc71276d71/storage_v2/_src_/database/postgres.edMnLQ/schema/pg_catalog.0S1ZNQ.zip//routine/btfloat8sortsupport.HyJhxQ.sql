create function btfloat8sortsupport(internal) returns void
as
$$
btfloat8sortsupport
$$;

comment on function btfloat8sortsupport(internal) is 'sort support';

