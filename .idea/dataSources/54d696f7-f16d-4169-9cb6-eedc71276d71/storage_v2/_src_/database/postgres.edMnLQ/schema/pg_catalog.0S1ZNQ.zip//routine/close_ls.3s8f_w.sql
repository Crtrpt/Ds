create function close_ls(line, lseg) returns point
as
$$
close_ls
$$;

comment on function close_ls(line, lseg) is 'implementation of ## operator';

