create function cotd(double precision) returns double precision
as
$$
dcotd
$$;

comment on function cotd(float8) is 'cotangent, degrees';

