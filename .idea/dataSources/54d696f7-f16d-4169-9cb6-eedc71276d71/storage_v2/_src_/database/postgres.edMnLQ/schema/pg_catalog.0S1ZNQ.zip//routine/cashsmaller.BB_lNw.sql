create function cashsmaller(money, money) returns money
as
$$
cashsmaller
$$;

comment on function cashsmaller(money, money) is 'smaller of two';

