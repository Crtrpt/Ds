create function "RI_FKey_setdefault_upd"() returns trigger
as
$$
RI_FKey_setdefault_upd
$$;

comment on function "RI_FKey_setdefault_upd"() is 'referential integrity ON UPDATE SET DEFAULT';

