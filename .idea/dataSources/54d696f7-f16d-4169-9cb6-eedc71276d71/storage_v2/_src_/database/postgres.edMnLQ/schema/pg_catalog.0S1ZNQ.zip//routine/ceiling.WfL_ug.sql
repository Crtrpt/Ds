create function ceiling(double precision) returns double precision
as
$$
dceil
$$;

comment on function ceiling(numeric) is 'nearest integer >= value';

