create function byteale(bytea, bytea) returns boolean
as
$$
byteale
$$;

comment on function byteale(bytea, bytea) is 'implementation of <= operator';

