create function cos(double precision) returns double precision
as
$$
dcos
$$;

comment on function cos(float8) is 'cosine';

