create function "current_user"() returns name
as
$$
current_user
$$;

comment on function "current_user"() is 'current user name';

