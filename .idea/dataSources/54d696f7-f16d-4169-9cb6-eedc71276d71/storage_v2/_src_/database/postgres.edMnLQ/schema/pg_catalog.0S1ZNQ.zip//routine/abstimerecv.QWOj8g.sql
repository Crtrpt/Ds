create function abstimerecv(internal) returns abstime
as
$$
abstimerecv
$$;

comment on function abstimerecv(internal) is 'I/O';

