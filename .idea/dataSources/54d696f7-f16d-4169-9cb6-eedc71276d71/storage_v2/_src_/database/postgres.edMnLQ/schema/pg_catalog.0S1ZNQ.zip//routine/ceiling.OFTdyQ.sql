create function ceiling(double precision) returns double precision
as
$$
dceil
$$;

comment on function ceiling(float8) is 'nearest integer >= value';

