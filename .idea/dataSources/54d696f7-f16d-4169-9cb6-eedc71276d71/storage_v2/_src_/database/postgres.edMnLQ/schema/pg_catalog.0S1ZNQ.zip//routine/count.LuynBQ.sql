create function count() returns bigint
as
$$
aggregate_dummy
$$;

comment on function count() is 'number of input rows';

