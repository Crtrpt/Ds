create function bttintervalcmp(tinterval, tinterval) returns integer
as
$$
bttintervalcmp
$$;

comment on function bttintervalcmp(tinterval, tinterval) is 'less-equal-greater';

