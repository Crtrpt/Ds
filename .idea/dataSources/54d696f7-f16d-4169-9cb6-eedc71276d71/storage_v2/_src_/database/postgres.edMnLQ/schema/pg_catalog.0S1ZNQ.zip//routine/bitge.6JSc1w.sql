create function bitge(bit, bit) returns boolean
as
$$
bitge
$$;

comment on function bitge(bit, bit) is 'implementation of >= operator';

