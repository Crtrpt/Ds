create function circle_mul_pt(circle, point) returns circle
as
$$
circle_mul_pt
$$;

comment on function circle_mul_pt(circle, point) is 'implementation of * operator';

