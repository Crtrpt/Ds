create function bpcharout(character) returns cstring
as
$$
bpcharout
$$;

comment on function bpcharout(bpchar) is 'I/O';

