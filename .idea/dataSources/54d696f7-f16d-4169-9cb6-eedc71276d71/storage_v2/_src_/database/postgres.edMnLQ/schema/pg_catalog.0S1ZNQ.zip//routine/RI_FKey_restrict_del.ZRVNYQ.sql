create function "RI_FKey_restrict_del"() returns trigger
as
$$
RI_FKey_restrict_del
$$;

comment on function "RI_FKey_restrict_del"() is 'referential integrity ON DELETE RESTRICT';

