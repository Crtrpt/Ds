create function cosd(double precision) returns double precision
as
$$
dcosd
$$;

comment on function cosd(float8) is 'cosine, degrees';

