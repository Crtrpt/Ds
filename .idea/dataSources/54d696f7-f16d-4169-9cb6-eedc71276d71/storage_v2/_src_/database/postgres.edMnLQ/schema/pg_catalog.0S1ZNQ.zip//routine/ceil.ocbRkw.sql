create function ceil(double precision) returns double precision
as
$$
dceil
$$;

comment on function ceil(numeric) is 'nearest integer >= value';

