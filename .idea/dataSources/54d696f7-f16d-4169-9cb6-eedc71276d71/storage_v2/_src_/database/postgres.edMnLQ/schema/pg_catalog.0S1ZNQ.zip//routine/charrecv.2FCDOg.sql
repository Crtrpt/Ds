create function charrecv(internal) returns "char"
as
$$
charrecv
$$;

comment on function charrecv(internal) is 'I/O';

