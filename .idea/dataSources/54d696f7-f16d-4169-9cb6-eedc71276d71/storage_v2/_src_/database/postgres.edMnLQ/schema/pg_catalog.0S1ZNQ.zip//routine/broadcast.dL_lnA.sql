create function broadcast(inet) returns inet
as
$$
network_broadcast
$$;

comment on function broadcast(inet) is 'broadcast address of network';

