create function bttext_pattern_sortsupport(internal) returns void
as
$$
bttext_pattern_sortsupport
$$;

comment on function bttext_pattern_sortsupport(internal) is 'sort support';

