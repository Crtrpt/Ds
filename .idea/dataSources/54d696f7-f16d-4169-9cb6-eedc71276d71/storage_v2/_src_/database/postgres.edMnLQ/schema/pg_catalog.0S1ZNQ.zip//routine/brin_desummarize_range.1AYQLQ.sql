create function brin_desummarize_range(regclass, bigint) returns void
as
$$
brin_desummarize_range
$$;

comment on function brin_desummarize_range(regclass, int8) is 'brin: desummarize page range';

