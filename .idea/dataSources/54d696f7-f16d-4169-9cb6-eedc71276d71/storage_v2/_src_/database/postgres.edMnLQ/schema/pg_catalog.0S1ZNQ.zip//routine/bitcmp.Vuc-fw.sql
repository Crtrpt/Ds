create function bitcmp(bit, bit) returns integer
as
$$
bitcmp
$$;

comment on function bitcmp(bit, bit) is 'less-equal-greater';

