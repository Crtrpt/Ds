create function date_cmp(date, date) returns integer
as
$$
date_cmp
$$;

comment on function date_cmp(date, date) is 'less-equal-greater';

