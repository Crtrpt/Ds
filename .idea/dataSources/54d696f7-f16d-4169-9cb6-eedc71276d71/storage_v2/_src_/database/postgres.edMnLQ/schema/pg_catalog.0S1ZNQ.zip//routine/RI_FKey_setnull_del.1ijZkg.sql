create function "RI_FKey_setnull_del"() returns trigger
as
$$
RI_FKey_setnull_del
$$;

comment on function "RI_FKey_setnull_del"() is 'referential integrity ON DELETE SET NULL';

