create function charlt("char", "char") returns boolean
as
$$
charlt
$$;

comment on function charlt("char", "char") is 'implementation of < operator';

