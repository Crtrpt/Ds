create function byteaeq(bytea, bytea) returns boolean
as
$$
byteaeq
$$;

comment on function byteaeq(bytea, bytea) is 'implementation of = operator';

