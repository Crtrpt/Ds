create function aclitemout(aclitem) returns cstring
as
$$
aclitemout
$$;

comment on function aclitemout(aclitem) is 'I/O';

