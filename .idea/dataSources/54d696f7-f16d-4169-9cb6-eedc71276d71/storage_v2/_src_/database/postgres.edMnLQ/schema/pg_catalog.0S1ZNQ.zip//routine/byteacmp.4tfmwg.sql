create function byteacmp(bytea, bytea) returns integer
as
$$
byteacmp
$$;

comment on function byteacmp(bytea, bytea) is 'less-equal-greater';

