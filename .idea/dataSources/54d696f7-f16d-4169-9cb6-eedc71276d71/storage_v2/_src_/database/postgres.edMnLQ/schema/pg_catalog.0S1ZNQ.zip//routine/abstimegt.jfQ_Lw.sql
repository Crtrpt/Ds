create function abstimegt(abstime, abstime) returns boolean
as
$$
abstimegt
$$;

comment on function abstimegt(abstime, abstime) is 'implementation of > operator';

