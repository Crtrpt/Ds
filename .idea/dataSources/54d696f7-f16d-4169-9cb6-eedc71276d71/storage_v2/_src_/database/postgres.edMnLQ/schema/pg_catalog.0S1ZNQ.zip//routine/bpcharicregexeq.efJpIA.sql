create function bpcharicregexeq(character, text) returns boolean
as
$$
texticregexeq
$$;

comment on function bpcharicregexeq(bpchar, text) is 'implementation of ~* operator';

