create function circle_out(circle) returns cstring
as
$$
circle_out
$$;

comment on function circle_out(circle) is 'I/O';

