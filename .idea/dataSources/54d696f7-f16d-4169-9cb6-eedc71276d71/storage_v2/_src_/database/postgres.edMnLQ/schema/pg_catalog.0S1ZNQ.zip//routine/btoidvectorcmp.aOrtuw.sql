create function btoidvectorcmp(oidvector, oidvector) returns integer
as
$$
btoidvectorcmp
$$;

comment on function btoidvectorcmp(oidvector, oidvector) is 'less-equal-greater';

