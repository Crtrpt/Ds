create function cideq(cid, cid) returns boolean
as
$$
cideq
$$;

comment on function cideq(cid, cid) is 'implementation of = operator';

