create function btint8sortsupport(internal) returns void
as
$$
btint8sortsupport
$$;

comment on function btint8sortsupport(internal) is 'sort support';

