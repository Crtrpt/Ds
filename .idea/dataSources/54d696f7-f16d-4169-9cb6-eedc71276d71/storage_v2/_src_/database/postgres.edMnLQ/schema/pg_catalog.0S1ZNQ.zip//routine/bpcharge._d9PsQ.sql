create function bpcharge(character, character) returns boolean
as
$$
bpcharge
$$;

comment on function bpcharge(bpchar, bpchar) is 'implementation of >= operator';

