create function convert(bytea, name, name) returns bytea
as
$$
pg_convert
$$;

comment on function convert(bytea, name, name) is 'convert string with specified encoding names';

