create function bttextcmp(text, text) returns integer
as
$$
bttextcmp
$$;

comment on function bttextcmp(text, text) is 'less-equal-greater';

