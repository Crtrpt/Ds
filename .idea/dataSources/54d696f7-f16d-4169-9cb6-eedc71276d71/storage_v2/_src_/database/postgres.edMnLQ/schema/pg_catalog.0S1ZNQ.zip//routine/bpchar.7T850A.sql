create function bpchar(name) returns character
as
$$
name_bpchar
$$;

comment on function bpchar("char") is 'convert char to char(n)';

