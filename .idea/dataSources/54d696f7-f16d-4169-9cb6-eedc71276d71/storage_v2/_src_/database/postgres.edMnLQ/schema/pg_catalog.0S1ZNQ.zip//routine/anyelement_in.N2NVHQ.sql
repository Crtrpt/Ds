create function anyelement_in(cstring) returns anyelement
as
$$
anyelement_in
$$;

comment on function anyelement_in(cstring) is 'I/O';

