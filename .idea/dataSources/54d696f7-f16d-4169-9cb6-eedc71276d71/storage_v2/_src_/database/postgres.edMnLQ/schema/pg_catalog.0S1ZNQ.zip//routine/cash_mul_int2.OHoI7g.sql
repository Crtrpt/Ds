create function cash_mul_int2(money, smallint) returns money
as
$$
cash_mul_int2
$$;

comment on function cash_mul_int2(money, int2) is 'implementation of * operator';

