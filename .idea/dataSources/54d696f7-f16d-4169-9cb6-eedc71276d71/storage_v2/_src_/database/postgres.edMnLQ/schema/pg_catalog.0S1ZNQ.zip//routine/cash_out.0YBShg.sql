create function cash_out(money) returns cstring
as
$$
cash_out
$$;

comment on function cash_out(money) is 'I/O';

