create function array_send(anyarray) returns bytea
as
$$
array_send
$$;

comment on function array_send(anyarray) is 'I/O';

