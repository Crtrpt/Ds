create function btoidcmp(oid, oid) returns integer
as
$$
btoidcmp
$$;

comment on function btoidcmp(oid, oid) is 'less-equal-greater';

