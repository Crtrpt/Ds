create function box(point, point) returns box
as
$$
points_box
$$;

comment on function box(polygon) is 'convert polygon to bounding box';

