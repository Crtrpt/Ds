create function date_le(date, date) returns boolean
as
$$
date_le
$$;

comment on function date_le(date, date) is 'implementation of <= operator';

