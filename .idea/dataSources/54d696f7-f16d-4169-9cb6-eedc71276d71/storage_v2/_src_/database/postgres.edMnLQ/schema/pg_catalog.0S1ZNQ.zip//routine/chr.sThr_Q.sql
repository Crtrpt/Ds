create function chr(integer) returns text
as
$$
chr
$$;

comment on function chr(int4) is 'convert int4 to char';

