create function box_eq(box, box) returns boolean
as
$$
box_eq
$$;

comment on function box_eq(box, box) is 'implementation of = operator';

