create function bitnot(bit) returns bit
as
$$
bitnot
$$;

comment on function bitnot(bit) is 'implementation of ~ operator';

