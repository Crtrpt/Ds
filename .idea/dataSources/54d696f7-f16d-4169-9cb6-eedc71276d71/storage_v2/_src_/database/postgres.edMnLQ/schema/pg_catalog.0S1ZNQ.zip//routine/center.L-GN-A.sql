create function center(box) returns point
as
$$
box_center
$$;

comment on function center(box) is 'center of';

