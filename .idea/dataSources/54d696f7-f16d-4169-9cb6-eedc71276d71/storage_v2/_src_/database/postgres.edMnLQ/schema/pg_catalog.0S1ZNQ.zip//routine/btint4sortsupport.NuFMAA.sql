create function btint4sortsupport(internal) returns void
as
$$
btint4sortsupport
$$;

comment on function btint4sortsupport(internal) is 'sort support';

