create function box_overabove(box, box) returns boolean
as
$$
box_overabove
$$;

comment on function box_overabove(box, box) is 'implementation of |&> operator';

