create function anyrange_out(anyrange) returns cstring
as
$$
anyrange_out
$$;

comment on function anyrange_out(anyrange) is 'I/O';

