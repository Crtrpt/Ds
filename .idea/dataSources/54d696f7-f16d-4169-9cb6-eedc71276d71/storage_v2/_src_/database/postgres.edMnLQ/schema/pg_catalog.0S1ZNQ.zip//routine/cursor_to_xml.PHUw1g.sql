create function cursor_to_xml(cursor refcursor, count integer, nulls boolean, tableforest boolean, targetns text) returns xml
as
$$
cursor_to_xml
$$;

comment on function cursor_to_xml(refcursor, int4, bool, bool, text) is 'map rows from cursor to XML';

