create function bool(integer) returns boolean
as
$$
int4_bool
$$;

comment on function bool(jsonb) is 'convert jsonb to boolean';

