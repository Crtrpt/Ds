create function ascii(text) returns integer
as
$$
ascii
$$;

comment on function ascii(text) is 'convert first char to int4';

