create function arraycontains(anyarray, anyarray) returns boolean
as
$$
arraycontains
$$;

comment on function arraycontains(anyarray, anyarray) is 'implementation of @> operator';

