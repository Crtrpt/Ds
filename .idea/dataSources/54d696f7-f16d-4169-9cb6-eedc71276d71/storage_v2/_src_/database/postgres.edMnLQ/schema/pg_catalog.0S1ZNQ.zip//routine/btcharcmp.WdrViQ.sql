create function btcharcmp("char", "char") returns integer
as
$$
btcharcmp
$$;

comment on function btcharcmp("char", "char") is 'less-equal-greater';

