create function bpcharlike(character, text) returns boolean
as
$$
textlike
$$;

comment on function bpcharlike(bpchar, text) is 'implementation of ~~ operator';

