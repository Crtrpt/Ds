create function cash_send(money) returns bytea
as
$$
cash_send
$$;

comment on function cash_send(money) is 'I/O';

