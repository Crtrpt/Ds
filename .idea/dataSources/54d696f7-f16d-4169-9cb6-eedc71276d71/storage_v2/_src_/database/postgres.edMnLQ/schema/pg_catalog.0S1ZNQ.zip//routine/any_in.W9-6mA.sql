create function any_in(cstring) returns "any"
as
$$
any_in
$$;

comment on function any_in(cstring) is 'I/O';

