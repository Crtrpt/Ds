create function btrecordimagecmp(record, record) returns integer
as
$$
btrecordimagecmp
$$;

comment on function btrecordimagecmp(record, record) is 'less-equal-greater based on byte images';

