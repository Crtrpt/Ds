create function bpchartypmodin(cstring[]) returns integer
as
$$
bpchartypmodin
$$;

comment on function bpchartypmodin(_cstring) is 'I/O typmod';

