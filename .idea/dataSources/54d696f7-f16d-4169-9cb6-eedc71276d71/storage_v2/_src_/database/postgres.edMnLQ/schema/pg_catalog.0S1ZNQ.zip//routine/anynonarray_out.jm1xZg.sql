create function anynonarray_out(anynonarray) returns cstring
as
$$
anynonarray_out
$$;

comment on function anynonarray_out(anynonarray) is 'I/O';

