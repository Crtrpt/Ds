create function center(box) returns point
as
$$
box_center
$$;

comment on function center(circle) is 'center of';

