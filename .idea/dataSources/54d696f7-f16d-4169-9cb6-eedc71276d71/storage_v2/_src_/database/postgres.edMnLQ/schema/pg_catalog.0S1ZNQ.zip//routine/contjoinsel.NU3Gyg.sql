create function contjoinsel(internal, oid, internal, smallint, internal) returns double precision
as
$$
contjoinsel
$$;

comment on function contjoinsel(internal, oid, internal, int2, internal) is 'join selectivity for containment comparison operators';

