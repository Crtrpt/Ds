create function charge("char", "char") returns boolean
as
$$
charge
$$;

comment on function charge("char", "char") is 'implementation of >= operator';

