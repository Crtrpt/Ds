create function btabstimecmp(abstime, abstime) returns integer
as
$$
btabstimecmp
$$;

comment on function btabstimecmp(abstime, abstime) is 'less-equal-greater';

