create function abs(real) returns real
as
$$
float4abs
$$;

comment on function abs(float4) is 'absolute value';

