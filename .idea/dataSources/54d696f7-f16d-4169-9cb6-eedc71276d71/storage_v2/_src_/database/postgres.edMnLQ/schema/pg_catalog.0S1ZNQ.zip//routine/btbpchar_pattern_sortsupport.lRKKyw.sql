create function btbpchar_pattern_sortsupport(internal) returns void
as
$$
btbpchar_pattern_sortsupport
$$;

comment on function btbpchar_pattern_sortsupport(internal) is 'sort support';

