create function boolgt(boolean, boolean) returns boolean
as
$$
boolgt
$$;

comment on function boolgt(bool, bool) is 'implementation of > operator';

