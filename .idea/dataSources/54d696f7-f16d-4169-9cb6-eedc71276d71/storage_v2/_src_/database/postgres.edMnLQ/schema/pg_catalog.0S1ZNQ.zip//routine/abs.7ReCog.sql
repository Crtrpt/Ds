create function abs(real) returns real
as
$$
float4abs
$$;

comment on function abs(float8) is 'absolute value';

