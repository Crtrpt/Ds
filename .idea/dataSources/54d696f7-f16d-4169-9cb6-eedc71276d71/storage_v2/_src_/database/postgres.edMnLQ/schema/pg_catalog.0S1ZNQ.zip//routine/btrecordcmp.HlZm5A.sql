create function btrecordcmp(record, record) returns integer
as
$$
btrecordcmp
$$;

comment on function btrecordcmp(record, record) is 'less-equal-greater';

