create function anyenum_in(cstring) returns anyenum
as
$$
anyenum_in
$$;

comment on function anyenum_in(cstring) is 'I/O';

