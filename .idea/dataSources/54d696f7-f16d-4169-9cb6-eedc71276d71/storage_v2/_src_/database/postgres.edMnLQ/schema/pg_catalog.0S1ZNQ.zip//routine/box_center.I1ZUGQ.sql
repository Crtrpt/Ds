create function box_center(box) returns point
as
$$
box_center
$$;

comment on function box_center(box) is 'implementation of @@ operator';

