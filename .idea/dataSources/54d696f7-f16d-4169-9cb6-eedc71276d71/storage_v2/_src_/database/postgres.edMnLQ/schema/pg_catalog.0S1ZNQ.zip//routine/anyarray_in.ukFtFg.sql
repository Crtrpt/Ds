create function anyarray_in(cstring) returns anyarray
as
$$
anyarray_in
$$;

comment on function anyarray_in(cstring) is 'I/O';

