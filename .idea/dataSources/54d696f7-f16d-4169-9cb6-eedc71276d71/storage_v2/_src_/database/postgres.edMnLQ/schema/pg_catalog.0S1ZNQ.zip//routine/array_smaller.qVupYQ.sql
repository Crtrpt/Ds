create function array_smaller(anyarray, anyarray) returns anyarray
as
$$
array_smaller
$$;

comment on function array_smaller(anyarray, anyarray) is 'smaller of two';

