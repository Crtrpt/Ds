create function btreltimecmp(reltime, reltime) returns integer
as
$$
btreltimecmp
$$;

comment on function btreltimecmp(reltime, reltime) is 'less-equal-greater';

