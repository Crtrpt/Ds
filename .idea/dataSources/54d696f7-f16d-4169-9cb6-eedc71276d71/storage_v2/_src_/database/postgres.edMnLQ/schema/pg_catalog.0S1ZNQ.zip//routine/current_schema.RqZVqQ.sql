create function "current_schema"() returns name
as
$$
current_schema
$$;

comment on function "current_schema"() is 'current schema name';

