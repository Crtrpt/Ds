create function bttextsortsupport(internal) returns void
as
$$
bttextsortsupport
$$;

comment on function bttextsortsupport(internal) is 'sort support';

