create function abstimele(abstime, abstime) returns boolean
as
$$
abstimele
$$;

comment on function abstimele(abstime, abstime) is 'implementation of <= operator';

