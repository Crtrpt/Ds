create function btboolcmp(boolean, boolean) returns integer
as
$$
btboolcmp
$$;

comment on function btboolcmp(bool, bool) is 'less-equal-greater';

