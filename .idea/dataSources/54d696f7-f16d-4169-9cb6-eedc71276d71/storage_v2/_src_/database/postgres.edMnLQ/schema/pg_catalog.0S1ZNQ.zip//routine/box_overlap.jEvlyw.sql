create function box_overlap(box, box) returns boolean
as
$$
box_overlap
$$;

comment on function box_overlap(box, box) is 'implementation of && operator';

