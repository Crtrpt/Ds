create function byteage(bytea, bytea) returns boolean
as
$$
byteage
$$;

comment on function byteage(bytea, bytea) is 'implementation of >= operator';

