create function bpcharnlike(character, text) returns boolean
as
$$
textnlike
$$;

comment on function bpcharnlike(bpchar, text) is 'implementation of !~~ operator';

