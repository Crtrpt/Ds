create function byteagt(bytea, bytea) returns boolean
as
$$
byteagt
$$;

comment on function byteagt(bytea, bytea) is 'implementation of > operator';

