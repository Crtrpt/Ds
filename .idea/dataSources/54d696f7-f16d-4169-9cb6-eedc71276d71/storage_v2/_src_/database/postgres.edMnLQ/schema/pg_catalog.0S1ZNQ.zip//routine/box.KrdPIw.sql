create function box(point, point) returns box
as
$$
points_box
$$;

comment on function box(point) is 'convert point to empty box';

