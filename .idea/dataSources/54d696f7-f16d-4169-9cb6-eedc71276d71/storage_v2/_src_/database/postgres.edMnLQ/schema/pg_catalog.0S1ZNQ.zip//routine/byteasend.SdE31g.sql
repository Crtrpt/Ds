create function byteasend(bytea) returns bytea
as
$$
byteasend
$$;

comment on function byteasend(bytea) is 'I/O';

