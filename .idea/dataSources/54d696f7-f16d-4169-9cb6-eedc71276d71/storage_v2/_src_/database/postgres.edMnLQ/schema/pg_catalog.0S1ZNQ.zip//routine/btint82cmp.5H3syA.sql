create function btint82cmp(bigint, smallint) returns integer
as
$$
btint82cmp
$$;

comment on function btint82cmp(int8, int2) is 'less-equal-greater';

