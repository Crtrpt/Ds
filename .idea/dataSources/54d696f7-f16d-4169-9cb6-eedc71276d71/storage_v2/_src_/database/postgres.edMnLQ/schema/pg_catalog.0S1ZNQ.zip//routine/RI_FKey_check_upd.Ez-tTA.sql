create function "RI_FKey_check_upd"() returns trigger
as
$$
RI_FKey_check_upd
$$;

comment on function "RI_FKey_check_upd"() is 'referential integrity FOREIGN KEY ... REFERENCES';

