create function aclremove(aclitem[], aclitem) returns aclitem[]
as
$$
aclremove
$$;

comment on function aclremove(_aclitem, aclitem) is 'remove ACL item';

