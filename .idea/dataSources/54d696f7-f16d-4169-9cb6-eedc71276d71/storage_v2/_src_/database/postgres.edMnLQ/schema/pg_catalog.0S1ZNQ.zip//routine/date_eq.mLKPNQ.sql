create function date_eq(date, date) returns boolean
as
$$
date_eq
$$;

comment on function date_eq(date, date) is 'implementation of = operator';

