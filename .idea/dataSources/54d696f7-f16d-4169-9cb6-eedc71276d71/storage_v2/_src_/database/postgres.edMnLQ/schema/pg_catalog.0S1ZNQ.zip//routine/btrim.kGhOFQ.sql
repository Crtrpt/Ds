create function btrim(text, text) returns text
as
$$
btrim
$$;

comment on function btrim(text) is 'trim spaces from both ends of string';

