create function abbrev(cidr) returns text
as
$$
cidr_abbrev
$$;

comment on function abbrev(cidr) is 'abbreviated display of cidr value';

