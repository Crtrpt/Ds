create function aclcontains(aclitem[], aclitem) returns boolean
as
$$
aclcontains
$$;

comment on function aclcontains(_aclitem, aclitem) is 'contains';

