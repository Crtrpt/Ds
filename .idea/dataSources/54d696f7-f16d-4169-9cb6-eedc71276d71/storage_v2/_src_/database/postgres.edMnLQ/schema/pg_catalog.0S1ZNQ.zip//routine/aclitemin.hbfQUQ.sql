create function aclitemin(cstring) returns aclitem
as
$$
aclitemin
$$;

comment on function aclitemin(cstring) is 'I/O';

