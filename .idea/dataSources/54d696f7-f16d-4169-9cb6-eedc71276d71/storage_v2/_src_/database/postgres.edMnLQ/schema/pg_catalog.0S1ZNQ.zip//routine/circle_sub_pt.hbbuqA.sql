create function circle_sub_pt(circle, point) returns circle
as
$$
circle_sub_pt
$$;

comment on function circle_sub_pt(circle, point) is 'implementation of - operator';

